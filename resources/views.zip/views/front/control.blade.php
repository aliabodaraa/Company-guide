@extends('layouts.base')
@section('content')

<div class="container-fluid">
     <h2>Sidebar Dropdown</h2>
     <div style="overflow-x:auto;">
          <table>
               <tr>
                    <th>الأقسام الرئيسية</th>
                    <th>تعديل</th>
                    <th>حذف</th>
                    {{-- <th>Points</th>
                    <th>Points</th>
                    <th>Points</th>
                    <th>Points</th>
                    <th>Points</th>
                    <th>Points</th>
                    <th>Points</th>
                    <th>Points</th>
                    <th>Points</th> --}}
               </tr>
               <tr>
                    <td>Jill</td>
                    <td>Smith</td>
                    <td>50</td>
                    {{-- <td>50</td>
                    <td>50</td>
                    <td>50</td>
                    <td>50</td>
                    <td>50</td>
                    <td>50</td>
                    <td>50</td>
                    <td>50</td>
                    <td>50</td> --}}
               </tr>
          </table>
     </div>
</div>

@endsection
