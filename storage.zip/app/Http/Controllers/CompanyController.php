<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Company;

class CompanyController extends Controller
{
    //


    public function index(Request $request, Category $category)
    {
        //$cat=Category::find($category);//->dd();
        //dd($category);//->name);//->id);
        return view("companies.index",['category'=>$category]);
    }

    public function create(Request $request,Category $category){
        return view('companies.create' ,['category'=>$category]);
    }

    public function store(Request $request,Category $category){
        //dd($request);
        $inputs=$request->validate([
            'name'=>'required|max:255',
            'image'=>'sometimes|image',
            //'phone'=>'sometimes',
            //'email'=>'email',
            // 'email'=>'mimes:pdf',
        ]);
        //dd($request);
        if($request->image_link){
            $input=$request->image_link;
        }
        else if(request('image')){
            $input=time() .$request->image->getClientOriginalName();
            $request->image->move(public_path('storage/images/companies'),$input);
        }else{
            $input=null;
        }
        //dd($request);
        Company::create([
            'name'=>$request->name ,
            'image'=> $input ,
            'category_id'=>$category->id,
            'phone'=>$request->phone ,
            "email"=>$request->email,

        ]);
        $request->session()->flash('company-created-message',"تم إضافة الشركة بنجاح");
        //return back();
        return redirect()->route('companies.index',$category->id);
        //return view('companies.create' ,['category'=>$category]);
    }



    public function edit(Company $company){

        return view('companies.edit',['company'=>$company]);
    }
    
    
    
    public function update(Company $company,Request $request){
    
        if($request->name){
            $request->validate(['name'=>'max:255']);
            $company->name=$request->name;
        }
        if($request->phone){
            //$request->validate(['name'=>'max:255']);
            $company->phone=$request->phone;
        }
        if($request->email){
            //$request->validate(['name'=>'max:255']);
            $company->email=$request->email;
        }
        if($request->image_link){
            $company->image=$request->image_link;
            //dd($input);
        }
        if($request->category_id){
            $company->category_id=$request->category_id;
            //dd($input);
        }
        else if($file=$request->image){
            $request->validate(['image'=>'image']);
            $input=time() .$request->image->getClientOriginalName();
            $request->image->move(public_path('storage/images/companies'),$input);
            $company->image=$input;
        }


        $company->save();
        $request->session()->flash('company-updated-message','تم تعديل الشركة بنجاح');
        return redirect()->route('companies.index',$company->category->id);
    
    
    }
    
    public function destroy(Company $company,Request $request){
        //dd($company);
        $company->delete();
        //dd($company);
        $request->session()->flash('company-deleted-message',' تم حذف الشركة بنجاح');
        return back();
    
    }
    
}
