@extends('layouts.base')

@section('content')
<div class="container-fluid">
<h1 class="">تعديل قسم</h1>
<div class="container-fluid" >

     <form method="post" action="{{route('categories.update',$category)}}" enctype="multipart/form-data">

          @method("PATCH")
          @csrf
         
     
          <div class="form-group">
     
               <label for="name">اسم القسم</label>
               <input type="text" name="name" class="form-control" id="" aria-description="" placeholder="">
               @error('name')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>

          <div class="form-group">
               <select class="form-control" name="parent_id">
                 <option value="">Select Parent Category</option>
      
                 @foreach (App\Models\Category::all() as $category)
                   <option value="{{ $category->id }}">{{ $category->name }}</option>
                 @endforeach
               </select>
             </div>
          <button type="submit" class="btn btn-primary">تأكيد</button>
     </form>

</div>
</div>

    
@endsection