@extends('layouts.base')
@section('content')
<div class="container-fluid">
@if (Session::has('company-created-message'))
<div class="alert alert-primary">

  {{Session::get('company-created-message')}}
</div> 
@endif

@if (Session::has('company-updated-message'))
<div class="alert alert-success">

{{Session::get('company-updated-message')}}
</div> 
@endif
@if (Session::has('company-deleted-message'))
<div class="alert alert-danger">

{{Session::get('company-deleted-message')}}
</div> 
@endif
<h1 class="">إضافة شركة</h1>

     <form method="post" action="{{route('companies.store',$category->id)}}" enctype="multipart/form-data" >
          @csrf
          <div class="form-group">
               <label for="name">اسم الشركة</label>
               <input type="text" name="name" class="form-control" id="" aria-description="" placeholder="الاسم">
               @error('name')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>
          {{-- <div class="form-group">
     
               <label for="subcategory"> القسم الفرعي </label>
               <input type="text" name="subcategory" class="form-control" id="" aria-description="" placeholder="">
               @error('subcategory')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>
          <div class="form-group">    
               <label for="category"> القسم الذي تتبع له الشركة </label>
               <input type="text" name="category" class="form-control" id="" aria-description="" placeholder="">
               @error('category')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div> --}}
          <div class="form-group">
               <label for="image_link">رابط لصورة الشركة </label>
               <input type="link" name="image_link" class="form-control"  placeholder="رابط الصور">
               @error('image_link')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>
          <div class="form-group">
               <label for="file">صورة الشركة</label>
               <input type="file" name="image"  placeholder="">
               @error('image')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>  
          <div id="InputPhone">
               <label for="phones">أرقام الشركة </label>
               <input type="phone" class="form-control form-control-edit" name="phone[]" placeholder="أدخل الرقم"><br>
          </div>
           <a id="add-phone" class="btn btn-info" style="display: block;width: 30%;">إضافة رقم</a>
             
          
          <div id="InputEmails">
               <label for="Emails">ايميلات الشركة</label>
                <input type="email" class="form-control form-control-edit" name="email[]" placeholder="أدخل الإيميل"><br>
          </div>
           <a id="add-email" class="btn btn-info" style="width: 30%;">إضافة إيميل</a>



          <button type="submit" class="btn btn-primary btn-block" style="margin-top: 8px;margin-bottom: 8px;">Submit</button>  
     </form>
</div>
@endsection