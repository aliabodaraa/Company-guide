@extends('layouts.base')

@section('content')
<h1 class="">تعديل شركة</h1>
<div class="container-fluid" >
     <form method="post" action="{{route('companies.update',$company->id)}}" enctype="multipart/form-data" style='width:600px;'>
          @method("PATCH")
          @csrf
          <div class="form-group">
               <label for="name">اسم الشركة</label>
               <input type="text" name="name" class="form-control" id="" aria-description="" placeholder="{{$company->name}}">
               @error('name')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>
          <div class="form-group">
               <select class="form-control" name="parent_id">
                    {{-- <option value="{{$company->category->id}}">{{$company->category->name}}</option> --}}
                    @foreach (App\Models\Category::whereNotIn('id',App\Models\Category::whereNotNull('parent_id')->get('parent_id'))->get() as $category)
                         <option value="{{ $category->id }}" @if($category->id ==$company->category->id ) selected @endif>{{ $category->name }}</option>
                    @endforeach
               </select>
          </div>
          <div class="form-group">
               <label for="image_link">رابط لصورة الشركة </label>
               <input type="link" name="image_link" class="form-control-file"  placeholder="">
               @error('image_link')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>
          <div class="form-group">
               <label for="file">صورة الشركة</label>
               <input type="file" name="image" class="form-control-file"  placeholder="{{$company->image}}">
               <div class="container">
                    <img src="{{$company->image}}" alt="">
               </div>
               @error('image')
                    <div class="alert alert-danger">{{ $message }}</div>
               @enderror
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>     
     </form>
</div>
@endsection