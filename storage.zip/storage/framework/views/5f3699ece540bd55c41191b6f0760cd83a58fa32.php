
<ul class="sub submenu-<?php echo e($x); ?>">
     <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($child->children->count()>0): ?>
               <li class="contain-submenu"><a href="#"><?php echo e($child->name); ?></a>
                    <?php
                        if($x==3)
                        {
                             $x=0;
                        }
                    ?>
                    <?php echo $__env->make('category-partial ',['children' => $child->children ,'x'=>($x+1)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </li>
          <?php else: ?>
               <li class="active"><a href="<?php echo e(route('companies.index',$child->id)); ?>"><?php echo e($child->name); ?></a></li>
          <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/category-partial.blade.php ENDPATH**/ ?>