<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  
          <div class="">
               <a href="<?php echo e(route('subcategories.create')); ?>"><button class="btn btn-info btn-block" >أضف قسم جديد </button></a>
          </div>
     
        <table id="customers">
               <tr>
                    <th>الأقسام الفرعية</th>
                    <th>الأقسام الأساسية</th>
                    <th>تعديل</th>
                    <th>حذف</th>
               </tr>
               <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                         <td><?php echo e($subcategory->name); ?></td>
                         <td><?php echo e($subcategory->category->name); ?></td>
                         <td class="text-center">
                              <a href="<?php echo e(route('categories.edit',$subcategory->id)); ?>"><button class="btn btn-primary">تعديل</button></a>
                         </td>
                         <td class="text-right">
                              <form method="post" action="<?php echo e(route('subcategories.destroy',$subcategory->id)); ?>" enctype="multipart/form-data">
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('DELETE'); ?>
                                   <button class="btn btn-danger">حذف</button>
                              </form>
                         </td>
                    </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/subcategories/index.blade.php ENDPATH**/ ?>