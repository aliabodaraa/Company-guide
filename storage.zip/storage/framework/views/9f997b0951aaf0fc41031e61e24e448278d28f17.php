
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<?php if(Session::has('company-created-message')): ?>
<div class="alert alert-primary">

  <?php echo e(Session::get('company-created-message')); ?>

</div> 
<?php endif; ?>

<?php if(Session::has('company-updated-message')): ?>
<div class="alert alert-success">

<?php echo e(Session::get('company-updated-message')); ?>

</div> 
<?php endif; ?>
<?php if(Session::has('company-deleted-message')): ?>
<div class="alert alert-danger">

<?php echo e(Session::get('company-deleted-message')); ?>

</div> 
<?php endif; ?>
<h1 class="">إضافة شركة</h1>

     <form method="post" action="<?php echo e(route('companies.store',$category->id)); ?>" enctype="multipart/form-data" >
          <?php echo csrf_field(); ?>
          <div class="form-group">
               <label for="name">اسم الشركة</label>
               <input type="text" name="name" class="form-control" id="" aria-description="" placeholder="الاسم">
               <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
          <div class="form-group">
               <label for="image_link">رابط لصورة الشركة </label>
               <input type="link" name="image_link" class="form-control"  placeholder="رابط الصور">
               <?php $__errorArgs = ['image_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
               <label for="file">صورة الشركة</label>
               <input type="file" name="image"  placeholder="">
               <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>  
          <div id="InputPhone">
               <label for="phones">أرقام الشركة </label>
               <input type="phone" class="form-control form-control-edit" name="phone[]" placeholder="أدخل الرقم"><br>
          </div>
           <a id="add-phone" class="btn btn-info" style="display: block;width: 30%;">إضافة رقم</a>
             
          
          <div id="InputEmails">
               <label for="Emails">ايميلات الشركة</label>
                <input type="email" class="form-control form-control-edit" name="email[]" placeholder="أدخل الإيميل"><br>
          </div>
           <a id="add-email" class="btn btn-info" style="width: 30%;">إضافة إيميل</a>



          <button type="submit" class="btn btn-primary btn-block" style="margin-top: 8px;margin-bottom: 8px;">Submit</button>  
     </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/companies/create.blade.php ENDPATH**/ ?>