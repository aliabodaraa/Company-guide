
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<?php if(Session::has('company-created-message')): ?>
     <div class="alert alert-info">
          <?php echo e(Session::get('company-created-message')); ?>

     </div> 
<?php endif; ?>

<?php if(Session::has('company-updated-message')): ?>
     <div class="alert alert-success">
          <?php echo e(Session::get('company-updated-message')); ?>

     </div> 
<?php endif; ?>
<?php if(Session::has('company-deleted-message')): ?>
     <div class="alert alert-danger">
          <?php echo e(Session::get('company-deleted-message')); ?>

     </div> 
<?php endif; ?>

          <div class="">
               <a href="<?php echo e(route('companies.create',$category->id)); ?>"><button class="btn btn-primary btn-block" >أضف شركة جديدة </button></a>
          </div>
    
     <table id="customers">
               <tr>
                    <th>الشركة</th>
                    <th>صورة الشركة</th>
                    <th>الايميلات</th>
                    <th>الهواتف</th>
                    <th>تعديل</th>
                    <th>حذف</th>
               </tr>
               <?php $__currentLoopData = $category->companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                         <td><?php echo e($company->name); ?></td>
                         <td><img src="<?php echo e($company->image); ?>" alt=""   width="50px" height="50px"></td>
                         <td>
                              <select name="" id="">
                                   <?php $__currentLoopData = ($company->email); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item): ?>
                                             <option value=""><?php echo e($item); ?></option>
                                        <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                         </td>
                         <td>
                              <select name="" id="">
                                   <?php $__currentLoopData = ($company->phone); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item): ?>
                                             <option value=""><?php echo e($item); ?></option>
                                        <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                         </td>
                         <td class="text-center">
                              <a href="<?php echo e(route('companies.edit',$company->id)); ?>"><button class="btn btn-primary">تعديل</button></a>
                         </td>
                         <td class="text-right">
                              <form method="post" action="<?php echo e(route('companies.destroy',$company->id)); ?>" enctype="multipart/form-data">
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('DELETE'); ?>
                                   <button class="btn btn-danger">حذف</button>
                              </form>
                         </td>
                    </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
    
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/companies/index.blade.php ENDPATH**/ ?>