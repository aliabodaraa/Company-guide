

<?php $__env->startSection('content'); ?>
<h1 class="">تعديل شركة</h1>
<div class="container-fluid" >
     <form method="post" action="<?php echo e(route('companies.update',$company->id)); ?>" enctype="multipart/form-data" style='width:600px;'>
          <?php echo method_field("PATCH"); ?>
          <?php echo csrf_field(); ?>
          <div class="form-group">
               <label for="name">اسم الشركة</label>
               <input type="text" name="name" class="form-control" id="" aria-description="" placeholder="<?php echo e($company->name); ?>">
               <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
               <select class="form-control" name="parent_id">
                    
                    <?php $__currentLoopData = App\Models\Category::whereNotIn('id',App\Models\Category::whereNotNull('parent_id')->get('parent_id'))->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($category->id); ?>" <?php if($category->id ==$company->category->id ): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
          </div>
          <div class="form-group">
               <label for="image_link">رابط لصورة الشركة </label>
               <input type="link" name="image_link" class="form-control-file"  placeholder="">
               <?php $__errorArgs = ['image_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
               <label for="file">صورة الشركة</label>
               <input type="file" name="image" class="form-control-file"  placeholder="<?php echo e($company->image); ?>">
               <div class="container">
                    <img src="<?php echo e($company->image); ?>" alt="">
               </div>
               <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>     
     </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/companies/edit.blade.php ENDPATH**/ ?>