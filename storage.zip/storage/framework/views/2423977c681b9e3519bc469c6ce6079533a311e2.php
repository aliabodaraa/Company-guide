
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
     <h2>Sidebar Dropdown</h2>
     <div style="overflow-x:auto;">
          <table>
               <tr>
                    <th>الأقسام الرئيسية</th>
                    <th>تعديل</th>
                    <th>حذف</th>
                    
               </tr>
               <tr>
                    <td>Jill</td>
                    <td>Smith</td>
                    <td>50</td>
                    
               </tr>
          </table>
     </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/front/control.blade.php ENDPATH**/ ?>