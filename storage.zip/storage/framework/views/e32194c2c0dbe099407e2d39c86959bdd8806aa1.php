
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<?php if(Session::has('category-created-message')): ?>
     <div class="alert alert-info">
          <?php echo e(Session::get('category-created-message')); ?>

     </div> 
<?php endif; ?>

<?php if(Session::has('category-updated-message')): ?>
     <div class="alert alert-success">
          <?php echo e(Session::get('category-updated-message')); ?>

     </div> 
<?php endif; ?>
<?php if(Session::has('category-deleted-message')): ?>
     <div class="alert alert-danger">
          <?php echo e(Session::get('category-deleted-message')); ?>

     </div> 
<?php endif; ?>

          <div class="">
               <a href="<?php echo e(route('categories.create')); ?>"><button class="btn btn-primary btn-block" >أضف قسم جديد </button></a>
          </div>
    
     


       




<div class="row">
     <div class="col-md-12 dd" id="nestable-wrapper">
         <ol class="dd-list list-group" style="margin-left: -160px;margin-right: -30px;">
             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li class="first dd-item list-group-item" data-id="<?php echo e($category->id); ?>">
                     <div class="dd-handle" ><?php echo e($category->name); ?></div>
                     <div class="dd-option-handle">
                         <a href="<?php echo e(route('categories.edit',$category->id )); ?>" class="btn btn-success btn-sm" >تعديل</a> 


                         <div id="id02" class="modal">
                              <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">×</span>
                              <form class="modal-content" action="/action_page.php">
                              <div class="container">
                                    <h4 style=" color: #000000;
                                   text-align: center;
                                   margin-top: 3px;
                                   margin-bottom: 9px;
                                   font-size: 45px;
                                   font-weight: bold;"
                              > حذف هذا القسم سيؤدي إلى حذف جميع الأقسام بداخله</h4>
                                   <p> هل أنت متأكد أنك تريد حذف القسم ؟</p>
                              
                                   <div class="clearfix">
                                   <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">إلغاء</button>
                                   <button type="button" onclick="document.getElementById('id02').style.display='none';event.preventDefault();document.getElementById('delete<?php echo e($category->id); ?>').submit();" class="deletebtn"  ><a href="<?php echo e(route('categories.destroy',$category->id)); ?>"></a> تأكيد </button>
                                   </div>
                              </div>
                              </form>
                         </div>

                         <a class="btn btn-danger btn-sm"  onclick="document.getElementById('id02').style.display='block'" style="cursor: pointer;">حذف</a> 
                         <form id="delete<?php echo e($category->id); ?>"  method="post" action="<?php echo e(route('categories.destroy',$category->id)); ?>" enctype="multipart/form-data" style="display:none;">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              
                         </form>
                     </div>

                     <?php if(!empty($category->children)): ?>
                         <?php echo $__env->make('child-category-view', [ 'category' => $category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php endif; ?>
                 </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ol>
     </div>
 </div>
    
<?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/categories/index.blade.php ENDPATH**/ ?>