
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
     <div class="container">
          <div class="">
               <a href="<?php echo e(route('categories.createCompany',$category->id)); ?>"><button class="btn btn-success" >أضف شركة جديدة </button></a>
          </div>
     </div>
     <div style="overflow-x:auto;">
          <table>
               <tr>
                    <th>الشركة</th>
                    <th>تعديل</th>
                    <th>حذف</th>
               </tr>
               <?php $__currentLoopData = $category->companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                         <td><?php echo e($company->name); ?></td>
                         <td class="text-center">
                              <a href="<?php echo e(route('categories.edit',$company->id)); ?>"><button class="btn btn-primary">تعديل</button></a>
                         </td>
                         <td class="text-right">
                              <form method="post" action="<?php echo e(route('categories.destroy',$company->id)); ?>" enctype="multipart/form-data">
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('DELETE'); ?>
                                   <button class="btn btn-danger">حذف</button>
                              </form>
                         </td>
                    </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
     </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\resources\views/categories/detail.blade.php ENDPATH**/ ?>