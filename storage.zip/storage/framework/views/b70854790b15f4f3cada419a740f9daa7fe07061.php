<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Windows.10\Desktop\project2Update\companies\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>